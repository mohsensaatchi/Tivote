﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using NuGet.Common;
using System.Data.Entity;
using System.Globalization;
//using System.Data.Entity;
using Tivote.Data;
using Tivote.Models;

namespace Tivote.Controllers
{
    public class MealController : MainController
    {

        public MealController(TivoteDb context) : base(context)
        {
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult ReserveMeal()
        {
            return View();
        }
        public IActionResult CreateDailyMenu()
        {
            return View();
        }
        public IActionResult WeeklyReport()
        {
            return View();
        }
        public IActionResult AddSupplier()
        {
            return View();
        }
        //public async Task<IActionResult> Suppliers()
        //{
        //    //List<MealSupplier> suppliers = await Context.MealSuppliers.ToListAsync();
        //    //return View(suppliers);
        //}
        public IActionResult CreateSupplier()
        {
            return PartialView();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateSupplier([Bind("Name,Id")] MealSupplier mealSupplier)
        {
            if (ModelState.IsValid)
            {
                mealSupplier.Id = Guid.NewGuid();
                Context.Add(mealSupplier);
                await Context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(mealSupplier);
        }

        public IActionResult ThisWeek()
        {
            List<DateTime> thisWeek = new();
            DateTime today = DateTime.Today;
            int diff = (7 + (today.DayOfWeek - DayOfWeek.Saturday)) % 7;
            return View(today.AddDays(-1 * diff).Date);
            PersianCalendar persianCalendar = new();
            persianCalendar.fr
        }
    }
}

