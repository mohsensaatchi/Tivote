﻿using System.Diagnostics;
using System.Globalization;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Tivote.Data;
using Tivote.Models;
using Tivote.Models.ViewModels;

namespace Tivote.Controllers;

[Authorize]
public class HomeController : MainController
{
    public HomeController(TivoteDb context) : base(context)
    {
        
    }
    public IActionResult Index()
    {
        return View();
    }
    public IActionResult Privacy()
    {
        return View();
    }
    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
    public IActionResult OrderMeal()
    {
        WeeklyUserMeal weeklyUserMeal = new();
        List<DateTime> workingDays = new();

        return View(weeklyUserMeal);
    }
    public async Task<IActionResult> News(Guid id)
    {
        News? news = await Context.News.FindAsync(id);
        if (news is null)
        {
            return NotFound();
        }
        return View(news);
    }
    public void alaki()
    {
        News[] news = new News[5];
        for (int i = 0; i < 5; i++)
        {
            news[i] = new News();
            news[i].Title = "عنوان خبر " + i;
            news[i].Description = "توضیح کوتاه خبر " + i;
            news[i].ImageUrl = $"~/images/{i}.png";
            news[i].Content = "لورم ایپسوم متن ساختگی با تولید سادگی نامفهوم از صنعت چاپ و با استفاده از طراحان گرافیک است. چاپگرها و متون بلکه روزنامه و مجله در ستون و سطرآنچنان که لازم است و برای شرایط فعلی تکنولوژی مورد نیاز و کاربردهای متنوع با هدف بهبود ابزارهای کاربردی می باشد. کتابهای زیادی در شصت و سه درصد گذشته، حال و آینده شناخت فراوان جامعه و متخصصان را می طلبد تا با نرم افزارها شناخت بیشتری را برای طراحان رایانه ای علی الخصوص طراحان خلاقی و فرهنگ پیشرو در زبان فارسی ایجاد کرد. در این صورت می توان امید داشت که تمام و دشواری موجود در ارائه راهکارها و شرایط سخت تایپ به پایان رسد وزمان مورد نیاز شامل حروفچینی دستاوردهای اصلی و جوابگوی سوالات پیوسته اهل دنیای موجود طراحی اساسا مورد استفاده قرار گیرد.";
        }
        Context.News.AddRange(news);
        Context.SaveChanges();
    }
}
