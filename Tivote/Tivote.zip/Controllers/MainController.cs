﻿using Microsoft.AspNetCore.Mvc;
using System.Data.Entity;
using Tivote.Data;
using Tivote.Models;

namespace Tivote.Controllers
{
    public class MainController : Controller
    {
        private readonly TivoteDb _context;

        public MainController(TivoteDb context)
        {
            _context = context;
        }
        public TivoteDb Context => _context;
        public async Task<IEnumerable<UsefulLink>> UsefulLinks()
        {
            return await _context.UsefulLinks.ToListAsync();
        }
        public async Task<IEnumerable<LinkCategory>> LinkCategories()
        {
                return await _context.LinkCategories.ToListAsync();
        }
        public List<SidebarMenuItem> SidebarMenuItems = new();
    }
}
