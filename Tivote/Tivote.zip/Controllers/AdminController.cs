﻿using Microsoft.AspNetCore.Mvc;
using Tivote.Data;
using Tivote.Models;

namespace Tivote.Controllers
{
    public class AdminController : MainController
    {
        public AdminController(TivoteDb context) : base(context)
        {
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Users()
        {
            return View();
        }
        public IActionResult Roles()
        {
            return View();
        }
        public IActionResult Permissions()
        {
            return View();
        }
        public IActionResult CreateUser()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("Name,Id")] User user)
        {

            if (ModelState.IsValid)
            {
                user.Id = Guid.NewGuid();
                Context.Add(user);
                await Context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(user);
        }
    }
}
