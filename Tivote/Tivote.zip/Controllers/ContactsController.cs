﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Tivote.Data;
using Tivote.Models;
using Tivote.Models.ViewModels;

namespace Tivote.Controllers
{
    public class ContactsController : MainController
    {
        public ContactsController(TivoteDb context) : base(context)
        {
        }
        public async Task<IActionResult> Index()
        {
            IEnumerable<Department> departments = await Context.Departments.ToListAsync();
            return View(departments);
        }
        public IActionResult SearchContact()
        {
            return View(new SearchContact());
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> SearchContact([Bind("SearchText")] SearchContact searchContact)
        {
            if (ModelState.IsValid)
            {
                _ = await Context.Departments.ToListAsync();
                _ = await Context.Locations.ToListAsync();
                searchContact.SearchText = searchContact.SearchText.ToLower();
                IEnumerable<User> contacts = await Context.Users
                    .Where(c => c.FirstName.ToLower().Contains(searchContact.SearchText) ||
                                c.LastName.ToLower().Contains(searchContact.SearchText) ||
                                c.Email.ToLower().Contains(searchContact.SearchText) ||
                                c.Number.ToLower().Contains(searchContact.SearchText)||
                                c.Department.Name.ToLower().Contains(searchContact.SearchText)||
                                c.Location.Name.ToLower().Contains(searchContact.SearchText))
                    .ToListAsync();
                searchContact.SerchResult.AddRange(contacts);

            }
            return View(searchContact);
        }
        public ActionResult Details(int Id)
        {
            return PartialView("_Details", new SearchContact());
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Details([Bind("SearchText")] SearchContact searchContact)
        {
            if (ModelState.IsValid)
            {
                _ = await Context.Departments.ToListAsync();
                _ = await Context.Locations.ToListAsync();
                searchContact.SearchText = searchContact.SearchText.ToLower();
                IEnumerable<User> contacts = await Context.Users
                    .Where(c => c.FirstName.ToLower().Contains(searchContact.SearchText) ||
                                c.LastName.ToLower().Contains(searchContact.SearchText) ||
                                c.Email.ToLower().Contains(searchContact.SearchText) ||
                                c.Number.ToLower().Contains(searchContact.SearchText) ||
                                c.Department.Name.ToLower().Contains(searchContact.SearchText) ||
                                c.Location.Name.ToLower().Contains(searchContact.SearchText))
                    .ToListAsync();
                searchContact.SerchResult.AddRange(contacts);

            }
            return PartialView("_Details", new SearchContact());
        }
        public IActionResult CreateLocation()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateLocation([Bind("Name,Id")] Department department)
        {
            if (ModelState.IsValid)
            {
                department.Id = Guid.NewGuid();
                Context.Add(department);
                await Context.SaveChangesAsync();
                return RedirectToAction(nameof(GroupByDepartments));
            }
            return View(department);
        }
        public IActionResult CreateDepartment()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateDepartment([Bind("Name,Id")] Department department)
        {
            if (ModelState.IsValid)
            {
                department.Id = Guid.NewGuid();
                Context.Add(department);
                await Context.SaveChangesAsync();
                return RedirectToAction(nameof(GroupByDepartments));
            }
            return View(department);
        }
        public IActionResult CreateUser()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateUser([Bind("FirstName,LastName,Number,Email,PersonelNumber,LocationId,DepartmentId,Id")] User user)
        {
            if (ModelState.IsValid)
            {
                user.Id = Guid.NewGuid();
                Context.Add(user);
                await Context.SaveChangesAsync();
                return RedirectToAction(nameof(GroupByDepartments));
            }
            return View(user);
        }
        public async Task<IActionResult> GroupByDepartments()
        {
            _ = await Context.Users.ToListAsync();
            _ = await Context.Locations.ToListAsync();
            IEnumerable<Department> departments = await Context.Departments.ToListAsync();
            return View(departments);
        }
        public async Task<IActionResult> GroupByLocations()
        {
            _ = await Context.Users.ToListAsync();
            _ = await Context.Departments.ToListAsync();
            IEnumerable<Location> locations = await Context.Locations.ToListAsync();
            return View(locations);
        }

        public async Task<IActionResult> GroupByLastName()
        {
            _ = await Context.Users.ToListAsync();
            _ = await Context.Departments.ToListAsync();
            _ = await Context.Locations.ToListAsync();
            Dictionary<string,List<User>> alphbeticalGroups = new();
            IEnumerable<User> users = await Context.Users.OrderBy(u => u.LastName).ToListAsync();
            foreach (var user in users)
            {
                if (alphbeticalGroups.ContainsKey(user.LastName[0].ToString()))
                {
                    alphbeticalGroups[user.LastName[0].ToString()].Add(user);
                }
                else
                {
                    List<User> usersList = new();
                    alphbeticalGroups.Add(user.LastName[0].ToString(), usersList);
                    alphbeticalGroups[user.LastName[0].ToString()].Add(user);
                }
            }
            return View(alphbeticalGroups);
        }
        public void SeedDepartments()
        {
            Department[] departments = new Department[12]
            {
                new Department { Id = Guid.NewGuid(), Name = "دفتر مدیرعامل" },
                new Department { Id = Guid.NewGuid(), Name = "معاونت مالی و اعتبارات" },
                new Department { Id = Guid.NewGuid(), Name = "معاونت زیرساخت و پشتیبانی" },
                new Department { Id = Guid.NewGuid(), Name = "مدیریت HSEQ" },
                new Department { Id = Guid.NewGuid(), Name = "معاونت سرمایه‌گذاری و کسب و کارهای نو" },
                new Department { Id = Guid.NewGuid(), Name = "معاونت طرح و برنامه" },
                new Department { Id = Guid.NewGuid(), Name = "مدیریت توسعه منابع انسانی" },
                new Department { Id = Guid.NewGuid(), Name = "مدیریت حقوقی و قراردادها" },
                new Department { Id = Guid.NewGuid(), Name = "بخش مخازن" },
                new Department { Id = Guid.NewGuid(), Name = "بخش یوتیلیتی و فرایندی" },
                new Department { Id = Guid.NewGuid(), Name = "بخش مهندسی و ساخت تجهیزات" },
                new Department { Id = Guid.NewGuid(), Name = "بخش تجارت بین الملل و تامین کالا" }
            };
            Context.Departments.AddRange(departments);
            Context.SaveChanges();
        }
        public void SeedLocations()
        {
            Location[] locations = new Location[6]
            {
                new Location { Id = Guid.NewGuid(), Name = "طبقه اول غربی" },
                new Location { Id = Guid.NewGuid(), Name = "طبقه اول شرقی" },
                new Location { Id = Guid.NewGuid(), Name = "طبقه دوم غربی" },
                new Location { Id = Guid.NewGuid(), Name = "طبقه دوم شرقی" },
                new Location { Id = Guid.NewGuid(), Name = "طبقه سوم غربی" },
                new Location { Id = Guid.NewGuid(), Name = "طبقه سوم شرقی" }
            };
            Context.Locations.AddRange(locations);
            Context.SaveChanges();
        }

        public async Task<IActionResult> CreateContact()
        {
            
            IEnumerable<Department> departments = await Context.Departments.ToListAsync();
            IEnumerable<Location> locations = await Context.Locations.ToListAsync();
            SelectListItem[] departmentsItems = new SelectListItem[departments.Count()];
            SelectListItem[] locationsItems = new SelectListItem[locations.Count()];
            for (int i = 0; i < departments.Count(); i++)
            {
                departmentsItems[i] = new SelectListItem { Value = departments.ElementAt(i).Id.ToString(), Text = departments.ElementAt(i).Name };
            }
            for (int i = 0; i < locations.Count(); i++)
            {
                locationsItems[i] = new SelectListItem { Value = locations.ElementAt(i).Id.ToString(), Text = locations.ElementAt(i).Name };
            }
            ViewData["DepartmentId"] = departmentsItems;
            ViewData["LocationId"] = locationsItems;
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateContact([Bind("FirstName,LastName,Number,Email,LocationId,DepartmentId,Id")] ContactDto userDto)
        {
            if (ModelState.IsValid)
            {
                Department? department = await Context.Departments.FindAsync(userDto.DepartmentId);
                Location? location = await Context.Locations.FindAsync(userDto.LocationId);
                if (department == null || location == null)
                {
                    return NotFound();
                }
                User user = new User
                {
                    Id = Guid.NewGuid(),
                    FirstName = userDto.FirstName,
                    LastName = userDto.LastName,
                    Number = userDto.Number,
                    Email = userDto.Email,
                    Department = department,
                    Location = location
                };
                user.Id = Guid.NewGuid();
                Context.Add(user);
                await Context.SaveChangesAsync();
                return RedirectToAction(nameof(GroupByDepartments));
            }
            return View(userDto);
        }
    }
}



