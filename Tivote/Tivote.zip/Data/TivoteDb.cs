using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.EntityFrameworkCore;
using Tivote.Models;

namespace Tivote.Data
{
    public class TivoteDb : DbContext
    {
        public TivoteDb(DbContextOptions<TivoteDb> options)
            : base(options)
        {
        }

        public DbSet<Department> Departments { get; set; } = default!;
        public DbSet<LinkCategory> LinkCategories { get; set; } = default!;
        public DbSet<Location> Locations { get; set; } = default!;
        public DbSet<News> News { get; set; } = default!;
        public DbSet<NewsCategory> NewsCategories { get; set; } = default!;
        public DbSet<Permission> Permissions { get; set; } = default!;
        public DbSet<Role> Roles { get; set; } = default!;
        public DbSet<SupplierMenuItem> SupplierMenuItems { get; set; } = default!;
        public DbSet<UsefulLink> UsefulLinks { get; set; } = default!;
        public DbSet<User> Users { get; set; } = default!;
        //public DbSet<DailyMeal> DailyMeals { get; set; } = default!;
        //public DbSet<HolyDay> HolyDays { get; set; } = default!;
        //public DbSet<Meal> Meals { get; set; } = default!;
        //public DbSet<MealSupplier> MealSuppliers { get; set; } = default!;
        //public DbSet<UserMeal> UserMeals { get; set; } = default!;

    }
}
