﻿using System;
using System.ComponentModel;

namespace Tivote.Models
{
    public class UserMeal : Entity
    {
        [DisplayName("کاربر")]
        public User User { get; set; } = default!;
        [DisplayName("تاریخ")]
        public DateTime Date { get; set; }
        [DisplayName("غذای روزانه")]
        public DailyMeal Meal { get; set; } = default!;
        [DisplayName("محل تحویل")]
        public Location DeliveryPlace { get; set; } = default!;
    }
}

