﻿using System.ComponentModel;

namespace Tivote.Models
{
    public class NewsCategory : Entity
    {
        [DisplayName("نام")]
        public string Name { get; set; } = string.Empty;
    }
}
