﻿using System;
namespace Tivote.Models.ViewModels
{
    public class WeeklyUserMeal
    {
        public WeeklyUserMeal()
        {
        }
        public User User { get; set; } = default!;
        public List<DailyMeal> DailyMeals { get; set; } = new();
    }
}

