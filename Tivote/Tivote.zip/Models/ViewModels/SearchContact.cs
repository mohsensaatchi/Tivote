﻿namespace Tivote.Models.ViewModels
{
    public class SearchContact
    {
        public string SearchText { get; set; }
        public List<User> SerchResult { get; set; } = new();
    }
}
