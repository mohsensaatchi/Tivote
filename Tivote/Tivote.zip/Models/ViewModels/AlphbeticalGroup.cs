﻿namespace Tivote.Models.ViewModels
{
    public class AlphbeticalGroup
    {
        public string FirstLetter { get; set; }
        public int Count { get; set; }
        public List<User> Users { get; set; }
    }
}
