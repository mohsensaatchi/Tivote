﻿using System;
using System.ComponentModel;

namespace Tivote.Models
{
    public class DailyMeal : Entity
    {
        [DisplayName("تاریخ")]
        public DateTime Date { get; set; } = DateTime.Now;
        [DisplayName("غذاهای روز")]
        public List<string> Meals { get; set; } = new();
    }
}

