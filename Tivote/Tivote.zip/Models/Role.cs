﻿using System;
using System.ComponentModel;

namespace Tivote.Models
{
    public class Role : Entity
    {
        [DisplayName("نام نقش")]
        public string Name { get; set; } = string.Empty;
        [DisplayName("مجوزها")]
        public List<Permission> Permissions { get; set; } = new();
        [DisplayName("نقشهای کاربری")]
        public List<Role> Roles { get; set; } = new();
    }
}

