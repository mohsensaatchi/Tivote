﻿namespace Tivote.Models
{
    public class SidebarMenuItem
    {
        public string Text { get; set; } = string.Empty;
        public string Area { get; set; } = string.Empty;
        public string Controller { get; set; } = string.Empty;
        public string Action { get; set; } = string.Empty;
    }
}
