﻿using System;
using System.ComponentModel;

namespace Tivote.Models
{
    public class Department : Entity
    {
        [DisplayName("مجموعه سازمانی")]
        public string Name { get; set; } = string.Empty;
        [DisplayName("کارکنان")]
        public List<User> Users { get; set; } = new();
    }
}

