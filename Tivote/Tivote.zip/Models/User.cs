﻿using System;
using System.ComponentModel;

namespace Tivote.Models
{
    public class User : Entity
    {
        [DisplayName("نام کاربری")]
        public string Name => Email.Split("@")[0];
        [DisplayName("نام")]
        public string FirstName { get; set; } = string.Empty;
        [DisplayName("نام خانوادگی")]
        public string LastName { get; set; } = string.Empty;
        [DisplayName("شماره داخلی")]
        public string Number { get; set; } = string.Empty;
        [DisplayName("ایمیل")]
        public string Email { get; set; } = string.Empty;
        [DisplayName("شماره پرسنلی")]
        public string PersonelNumber { get; set; } = string.Empty;
        [DisplayName("محل استقرار")]
        public Location Location { get; set; } = default!;
        [DisplayName("واحد")]
        public Department Department { get; set; } = default!;
        [DisplayName("نقشهای کاربری")]
        public List<Role> Roles { get; set; } = new();
    }
}

