﻿using System.ComponentModel;

namespace Tivote.Models
{
    public class Location : Entity
    {
        [DisplayName("موقعیت")]
        public string Name { get; set; } = string.Empty;
        public List<User> Users { get; set; } = new();
    }
}
